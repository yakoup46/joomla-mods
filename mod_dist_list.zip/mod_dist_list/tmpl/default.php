<?
defined('_JEXEC') or die;

?>
hi
