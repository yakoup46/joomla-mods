

function ShipToBillPerson(form) {
if (form.copy.checked) {
form.Billbusiness.value = form.business.value;
form.BillName.value = form.Name.value;
form.BillAddress.value = form.Address.value;
form.BillAddress2.value = form.Address2.value;
form.BillCity.value = form.City.value;
form.BillZipCode.value = form.ZipCode.value;
form.BillState.value = form.State.value;
form.BillCountry.value = form.Country.value;
form.BillTelephone.value = form.Telephone.value;
}

}

function ShipToDistBillPerson(form) {
if (form.copy.checked) {
form.shipaddr.value = form.billaddr.value;
form.shipcity.value = form.billcity.value;
form.shipzip.value = form.billzip.value;
form.shipstate.value = form.billstate.value;
form.shipcountry.value = form.billcountry.value;
}

}
function validatefields(form) {

if (!emailCheck (form.email.value)) {
    form.email.focus();
    return false;
}


if (form.business.value.length < 1) {
    alert('Business / University must be entered!');
    form.business.focus();
    return false;
}

if (form.Name.value.length < 1) {
    alert('Name must be entered!');
    form.Name.focus();
    return false;
}

if (form.Address.value.length < 1) {
    alert('Address must be entered!');
    form.Address.focus();
    return false;
}

if (form.City.value.length < 1) {
    alert('City must be entered!');
    form.City.focus();
    return false;
}

if (form.State.selectedIndex == "") {
    alert('State must be entered!');
    form.State.focus();
    return false;
}

if (form.ZipCode.value.length < 1) {
    alert('Zip Code must be entered!');
    form.ZipCode.focus();
    return false;
}



if (form.Telephone.value.length < 1) {
    alert('Telephone must be entered!');
    form.Telephone.focus();
    return false;
}

if (form.Billbusiness.value.length < 1) {
    alert('Billing Business / University must be entered!');
    form.Billbusiness.focus();
    return false;
}

if (form.BillName.value.length < 1) {
    alert('Billing Name must be entered!');
    form.BillName.focus();
    return false;
}

if (form.BillAddress.value.length < 1) {
    alert('Billing Address must be entered!');
    form.BillAddress.focus();
    return false;
}

if (form.BillCity.value.length < 1) {
    alert('Billing City must be entered!');
    form.BillCity.focus();
    return false;
}

if (form.BillState.selectedIndex == "") {
    alert('Billing State must be entered!');
    form.BillState.focus();
    return false;
}

if (form.BillZipCode.value.length < 1) {
    alert('Billing Zip Code must be entered!');
    form.BillZipCode.focus();
    return false;
}



if (form.BillTelephone.value.length < 1) {
    alert('Billing Telephone must be entered!');
    form.BillTelephone.focus();
    return false;
}

if (form.electro.value == "") {
    alert('You need to selected a Electrospinning option!');
    form.electro.focus();
    return false;
}

return true;
}


function validateContact(form) {

if (!emailCheck (form.email.value)) {
    form.email.focus();
    return false;
}

if (form.business.value.length < 1) {
    alert('Business / University must be entered!');
    form.business.focus();
    return false;
}


if (form.ZipCode.value.length < 1) {
    alert('Zip Code must be entered!');
    form.ZipCode.focus();
    return false;
}

if (form.Country.value.length < 1) {
    alert('Country must be entered!');
    form.Country.focus();
    return false;
}

if (form.electro.value == "") {
    alert('You need to selected a Electrospinning option!');
    form.electro.focus();
    return false;
}

return true;
}

function validateemails(form) {
if (!emailCheck (form.emailaddress.value)) {
    form.emailaddress.focus();
    return false;
}   
return true;    
}

function validateDistributor(form) {

if (!emailCheck (form.email.value)) {
    form.email.focus();
    return false;
}

if (form.company_name.value.length < 1) {
    alert('Company Name must be entered!');
    form.company_name.focus();
    return false;
}


if (form.billaddr.value.length < 1) {
    alert('Billing Address must be entered!');
    form.billaddr.focus();
    return false;
}

if (form.billcity.value.length < 1) {
    alert('Billing City must be entered!');
    form.billcity.focus();
    return false;
}

if (form.billstate.selectedIndex == "") {
    alert('Billing State must be entered!');
    form.billstate.focus();
    return false;
}

if (form.billzip.value.length < 1) {
    alert('Billing Zip Code must be entered!');
    form.billzip.focus();
    return false;
}



if (form.billphone.value.length < 1) {
    alert('Billing Telephone must be entered!');
    form.billphone.focus();
    return false;
}





if (form.marketsapps.value.length < 1) {
    alert('Marketing Applications must be entered!');
    form.marketsapps.focus();
    return false;
}
if (form.marketcountries.value.length < 1) {
    alert('Marketing Countries must be entered!');
    form.marketcountries.focus();
    return false;
}
if (form.shipaddr.value.length < 1) {
    alert('Shipping Address must be entered!');
    form.shipaddr.focus();
    return false;
}
if (form.shipcity.value.length < 1) {
    alert('Shipping City must be entered!');
    form.shipcity.focus();
    return false;
}

if (form.shipzip.value.length < 1) {
    alert('Marketing Applications must be entered!');
    form.shipzip.focus();
    return false;
}
if (form.shipcountry.value.length < 1) {
    alert('Shipping Country must be entered!');
    form.mshipcountry.focus();
    return false;
}
if (form.contact.value.length < 1) {
    alert('Account Contact must be entered!');
    form.contact.focus();
    return false;
}
if (form.salesmanager.value.length < 1) {
    alert('Sales Manager must be entered!');
    form.salesmanager.focus();
    return false;
}

return true;
}


function ChkNumbers(field) {
var valid = "0123456789"
var ok = "yes";
var temp;
for (var i=0; i<field.value.length; i++) {
temp = "" + field.value.substring(i, i+1);
if (valid.indexOf(temp) == "-1") ok = "no";
}
if (ok == "no") {
alert("Invalid entry!  Only numbers are accepted!");
field.focus();
field.select();
return false;
  }
return true;
}

function emailCheck (emailStr) {

/* The following variable tells the rest of the function whether or not
to verify that the address ends in a two-letter country or well-known
TLD.  1 means check it, 0 means don't. */

var checkTLD=1;

/* The following is the list of known TLDs that an e-mail address must end with. */

var knownDomsPat=/^(com|net|org|edu|int|mil|gov|arpa|biz|aero|name|coop|info|pro|museum)$/;

/* The following pattern is used to check if the entered e-mail address
fits the user@domain format.  It also is used to separate the username
from the domain. */

var emailPat=/^(.+)@(.+)$/;

/* The following string represents the pattern for matching all special
characters.  We don't want to allow special characters in the address. 
These characters include ( ) < > @ , ; : \ " . [ ] */

var specialChars="\\(\\)><@,;:\\\\\\\"\\.\\[\\]";

/* The following string represents the range of characters allowed in a 
username or domainname.  It really states which chars aren't allowed.*/

var validChars="\[^\\s" + specialChars + "\]";

/* The following pattern applies if the "user" is a quoted string (in
which case, there are no rules about which characters are allowed
and which aren't; anything goes).  E.g. "jiminy cricket"@disney.com
is a legal e-mail address. */

var quotedUser="(\"[^\"]*\")";

/* The following pattern applies for domains that are IP addresses,
rather than symbolic names.  E.g. joe@[123.124.233.4] is a legal
e-mail address. NOTE: The square brackets are required. */

var ipDomainPat=/^\[(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\]$/;

/* The following string represents an atom (basically a series of non-special characters.) */

var atom=validChars + '+';

/* The following string represents one word in the typical username.
For example, in john.doe@somewhere.com, john and doe are words.
Basically, a word is either an atom or quoted string. */

var word="(" + atom + "|" + quotedUser + ")";

// The following pattern describes the structure of the user

var userPat=new RegExp("^" + word + "(\\." + word + ")*$");

/* The following pattern describes the structure of a normal symbolic
domain, as opposed to ipDomainPat, shown above. */

var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$");

/* Finally, let's start trying to figure out if the supplied address is valid. */

/* Begin with the coarse pattern to simply break up user@domain into
different pieces that are easy to analyze. */

var matchArray=emailStr.match(emailPat);

if (matchArray==null) {

/* Too many/few @'s or something; basically, this address doesn't
even fit the general mould of a valid e-mail address. */

alert("Email address seems incorrect (check @ and .'s)");
return false;
}
var user=matchArray[1];
var domain=matchArray[2];

// Start by checking that only basic ASCII characters are in the strings (0-127).

for (i=0; i<user.length; i++) {
if (user.charCodeAt(i)>127) {
alert("Ths username contains invalid characters.");
return false;
   }
}
for (i=0; i<domain.length; i++) {
if (domain.charCodeAt(i)>127) {
alert("Ths domain name contains invalid characters.");
return false;
   }
}

// See if "user" is valid 

if (user.match(userPat)==null) {

// user is not valid

alert("The username doesn't seem to be valid.");
return false;
}

/* if the e-mail address is at an IP address (as opposed to a symbolic
host name) make sure the IP address is valid. */

var IPArray=domain.match(ipDomainPat);
if (IPArray!=null) {

// this is an IP address

for (var i=1;i<=4;i++) {
if (IPArray[i]>255) {
alert("Destination IP address is invalid!");
return false;
   }
}
return true;
}

// Domain is symbolic name.  Check if it's valid.
 
var atomPat=new RegExp("^" + atom + "$");
var domArr=domain.split(".");
var len=domArr.length;
for (i=0;i<len;i++) {
if (domArr[i].search(atomPat)==-1) {
alert("The domain name does not seem to be valid.");
return false;
   }
}

/* domain name seems valid, but now make sure that it ends in a
known top-level domain (like com, edu, gov) or a two-letter word,
representing country (uk, nl), and that there's a hostname preceding 
the domain or country. */

if (checkTLD && domArr[domArr.length-1].length!=2 && 
domArr[domArr.length-1].search(knownDomsPat)==-1) {
alert("The address must end in a well-known domain (.com, .net) and must be lowercase or a two letter " + "country.");
return false;
}

// Make sure there's a host name preceding the domain.

if (len<2) {
alert("This address is missing a hostname!");
return false;
}

// If we've gotten this far, everything's valid!
return true;
}