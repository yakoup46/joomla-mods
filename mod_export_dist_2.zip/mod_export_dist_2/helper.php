<?php

class ModDistList
{
    public static function getDists()
    {

    }
}