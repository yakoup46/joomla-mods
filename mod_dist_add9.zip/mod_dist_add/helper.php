<?php

class ModDistAdd
{
    public static function addDist($params)
    {
    }
}